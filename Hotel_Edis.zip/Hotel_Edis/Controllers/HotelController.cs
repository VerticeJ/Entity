using System.Reflection.Metadata.Ecma335;
using Microsoft.AspNetCore.Mvc;

namespace Hotel_Edis
{
    [Route("[controller]")]
    [ApiController]

    public class HotelController : Controller
    {   
        // -------- POSTS ---------- //
        [HttpPost("Cliente")]
        public IActionResult CadastrarCliente(int CodCliente, string Nome, string Nacionalidade, string EMail)
        {
            using (var _context = new HotelEdisContext())
            {
                try
                {
                    foreach(Cliente cliente in _context.Clientes)
                    {
                        if(cliente.CodCliente == CodCliente){
                            return BadRequest("ERRO DE CADASTRO: Já existe um cliente com esse cadastro");
                        }
                    }

                    Cliente novo_cliente = new(Nome, Nacionalidade, EMail);
                    _context.Clientes.Add(novo_cliente);
                    _context.SaveChanges();

                    return Ok("CADASTRO COM SUCESSO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
        }

        [HttpPost("Funcionario")]
        public IActionResult CadastrarFuncionario(int CodFuncionario, string Nome, string Funcao)
        {
            using (var _context = new HotelEdisContext())
            {
                try
                {
                    foreach(Funcionario funcionario in _context.Funcionarios)
                    {
                        if(funcionario.CodFuncionario == CodFuncionario){
                            return BadRequest("ERRO DE CADASTRO: Já existe um funcionario com esse codigo");
                        }
                    }
                    Funcionario novo_funcionario = new(Nome, Funcao);

                    _context.Funcionarios.Add(novo_funcionario);
                    _context.SaveChanges();

                    return Ok("CADASTRO COM SUCESSO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
        }

        [HttpPost("Filial")]
        public IActionResult CadastrarFilial(string Nome, string Endereco, int NQuartos)
        {
            using (var _context = new HotelEdisContext())
            {
                try
                {
                    if(NQuartos <= 0)
                    {
                        return BadRequest("NUMERO DE QUARTOS INFORMADO INVALIDO, DEVE SER MAIOR A 0");
                    }

                    if(Endereco == null || Endereco == "")
                    {
                        return BadRequest("ENDEREÇO INFORMADO INVALIDO");
                    }

                    Filial nova_filial = new(Nome, Endereco, NQuartos);
                    _context.Filials.Add(nova_filial);
                    _context.SaveChanges();

                    return Ok("CADASTRO COM SUCESSO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
        }

        [HttpPost("Quarto")]
        public IActionResult CadastrarQuarto(string Numero, int CodFilial,string Tipo, string Status, int PessoasMax)
        {
            using (var _context = new HotelEdisContext())
            {
                try
                {   
                    List<Quarto> lista_quartos = _context.Quartos.ToList();
                    List<string> lista_num_filial = new();

                    foreach(Quarto quarto in lista_quartos){
                        if(quarto.CodFilial == CodFilial){
                            lista_num_filial.Add(quarto.Numero);
                        }
                    }

                    foreach(string num_quarto in lista_num_filial)
                    {
                        if(num_quarto == Numero){
                            return BadRequest("ERRO DE CADASTRO: Já existe um QUARTO com esse numero naquela Filial");
                        }
                    }

                    Quarto novo_quarto = new(Numero, CodFilial, Tipo, Status, PessoasMax);
                    _context.Quartos.Add(novo_quarto);
                    _context.SaveChanges();

                    return Ok("CADASTRO COM SUCESSO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
        }

        [HttpPost("Reserva")]
        public IActionResult FazerReserva(DateOnly DataIn, DateOnly DataOut, string Numero, int CodFuncionario, int CodCliente, string CapOpcional)
        {
            using (var _context = new HotelEdisContext())
            {
                try
                {   
                    List<Reserva> lista_reservas = _context.Reservas.ToList();
                    Quarto quarto_reserva = _context.Quartos.FirstOrDefault(Q => Q.Numero == Numero);
                    Cliente cliente = _context.Clientes.FirstOrDefault(C => C.CodCliente == CodCliente);
                    Funcionario funcionario = _context.Funcionarios.FirstOrDefault(F => F.CodFuncionario == CodFuncionario);

                    if(quarto_reserva == null){
                        return BadRequest("QUARTO INFORMADO NÃO EXISTE");
                    }

                    if(cliente == null){
                        return BadRequest("CLIENTE INFORMADO NÃO EXISTE");
                    }

                    if(funcionario == null){
                        return BadRequest("FUNCIONARIO INFORMADO NÃO EXISTE");
                    }

                    if(DataIn > DataOut){
                        return BadRequest("DATAS DE RESERVA INVALIDAS: Data de Check-Out não pode ser anterior a Check-In");
                    }

                    if(quarto_reserva.Status != "Disponível"){
                        return BadRequest("QUARTO INDISPONÍVEL.");
                    }
                    else{
                        foreach(Reserva reserva in lista_reservas)
                        {
                            if(reserva.Numero == Numero)
                            {
                                if((reserva.DataIn > DataIn && reserva.DataIn < DataOut) || 
                                    (reserva.DataOut > DataIn && reserva.DataOut < DataOut))
                                {
                                    return BadRequest("QUARTO INDISPONÍVEL");
                                }
                            }
                        }
                    }

                    Reserva nova_reserva = new(DataIn, DataOut, Numero, CodFuncionario, CodCliente, CapOpcional);

                    _context.Reservas.Add(nova_reserva);
                    _context.SaveChanges();

                    return Ok("RESERVA FEITA COM SUCESSO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
        }

        [HttpPost("Estadia")]
        public IActionResult CadastrarEstadia(double Valor, string FormaPagamento,  int CodReserva)
        {
            using (var _context = new HotelEdisContext())
            {
                try
                {   
                    Reserva reserva = _context.Reservas.FirstOrDefault(R => R.CodReserva == CodReserva);

                    if(reserva == null)
                    {
                        return NotFound("RESERVA INFORMADA NÃO EXISTE");
                    }
                    
                    reserva.CapOpcional = reserva.CapOpcional.ToUpper();

                    if (Valor < 0)
                    {
                        return BadRequest("O VALOR DA RESERVA NÃO PODE SER NEGATIVO");
                    }

                    if (FormaPagamento == null || FormaPagamento == "")
                    {
                        return BadRequest("INFORME A FORMA DE PAGAMENTO");
                    }

                    if(reserva.CapOpcional == "SIM")
                    {
                        Valor *= 1.25;
                    }                  

                    Estadia nova_estadia = new(Valor, FormaPagamento, CodReserva);
                    Estadia ant_estadia = _context.Estadia.FirstOrDefault(E => E.CodReserva == nova_estadia.CodReserva);

                    if(ant_estadia != null)
                    {
                        return BadRequest("JÁ FOI CONFIRMADA A ESTADIA PARA A RESERVA");
                    }
                    _context.Estadia.Add(nova_estadia);
                    _context.SaveChanges();

                    return Ok("ESTADIA CONFIRMADA COM SUCESSO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
        }

        [HttpPost("Consumo")]
        public IActionResult PedirConsumo(double Valor , string EntregueQuarto, int CodEstadia)
        {
            using (var _context = new HotelEdisContext())
            {
                try
                {   
                    EntregueQuarto = EntregueQuarto.ToUpper();
                    Estadia estadia = _context.Estadia.FirstOrDefault(E => E.CodEstadia == CodEstadia);

                    if(estadia == null)
                    {
                        return NotFound("ESTADIA INFORMADA NÃO EXISTE");
                    }

                    if (Valor < 0)
                    {
                        return BadRequest("O VALOR DO CONSUMO NÃO PODE SER NEGATIVO");
                    }

                    if (EntregueQuarto == null || EntregueQuarto == "")
                    {
                        return BadRequest("INFORME SE FOI ENTREGUE NO QUARTO");
                    }

                    else if(EntregueQuarto == "SIM")
                    {
                        Valor *= 1.1;
                    }

                    Consumo novo_consumo = new(Valor, EntregueQuarto, CodEstadia);
                    _context.Consumos.Add(novo_consumo);
                    _context.SaveChanges();

                    return Ok("CONSUMO LANÇADO COM SUCESSO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
        }
        
        // -------- GETS ---------- //
        [HttpGet("Cliente")]
        public IActionResult ListarClientes()
        {
            using (var _context = new HotelEdisContext())
            {
                return Ok( _context.Clientes.ToList());
            }
        }
        
        [HttpGet("Funcionario")]
        public IActionResult ListarFuncionario()
        {
            using (var _context = new HotelEdisContext())
            {
                return Ok( _context.Funcionarios.ToList());
            }
        }

        [HttpGet("Filial")]
        public IActionResult ListarFiliais()
        {
            using (var _context = new HotelEdisContext())
            {
                return Ok(_context.Filials.ToList());
            }
        }

        [HttpGet("Quarto")]
        public IActionResult ListarQuartos()
        {
            using (var _context = new HotelEdisContext())
            {
                return Ok( _context.Quartos.ToList());
            }
        }

        [HttpGet("QuartosPorFilial")]
        public IActionResult ListarQuartosFilial(int CodFilial)
        {
            using (var _context = new HotelEdisContext())
            {
                return Ok( _context.Quartos.Where(Q => Q.CodFilial == CodFilial).ToList());
            }
        }

        [HttpGet("Reservas")]
        public IActionResult VerReservas()
        {
            using (var _context = new HotelEdisContext())
            {
                return Ok( _context.Reservas.ToList());
            }
        }

        [HttpGet("ReservasPorCliente")]
        public IActionResult VerReservasCliente(int CodCliente)
        {
            using (var _context = new HotelEdisContext())
            {
                return Ok( _context.Reservas.Where(R => R.CodCliente == CodCliente).ToList());
            }
        }

        [HttpGet("ReservasPorFuncionario")]
        public IActionResult VerReservasFuncionario(int CodFuncionario)
        {
            using (var _context = new HotelEdisContext())
            {
                return Ok( _context.Reservas.Where(R => R.CodFuncionario == CodFuncionario).ToList());
            }
        }

        [HttpGet("Estadia")]
        public IActionResult VerEstadias()
        {
            using (var _context = new HotelEdisContext())
            {
                return Ok( _context.Estadia.ToList());
            }
        }

        [HttpGet("EstadiaPorCliente")]
        public IActionResult VerEstadiaCliente(int CodCliente)
        {
            using (var _context = new HotelEdisContext())
            {   
                var estadias_cliente = _context.Clientes.Where(C => C.CodCliente == CodCliente)
                .SelectMany(C => C.Reservas.Select(R => R.Estadia)).ToList();

                return Ok(estadias_cliente);
            }
        }

         [HttpGet("ConsumosPorEstadia")]
        public IActionResult ConsumosPorEstadia(int CodEstadia)
        {
            using (var _context = new HotelEdisContext())
            {
                return Ok(_context.Consumos.Where(C => C.CodEstadia == CodEstadia).ToList());
            }
        }

        // -------- DELETE ---------- //

        [HttpDelete("Cliente")]
        public IActionResult DeletarCliente(int CodCliente)
        {
            using (var _context = new HotelEdisContext())
            {
                try
                {
                    Cliente cliente = _context.Clientes.FirstOrDefault(C => C.CodCliente == CodCliente);
                    if(cliente == null)
                    {
                        return NotFound("CLIENTE INFORMADO NÃO EXISTE"); 
                    }
                    _context.Clientes.Remove(cliente);
                    _context.SaveChanges();

                    return Ok("CLIENTE DELETADO COM SUCESSO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
        }

        [HttpDelete("Funcionario")]
        public IActionResult DeletarFuncionario(int CodFuncionario)
        {
            using (var _context = new HotelEdisContext())
            {
                try
                {
                    Funcionario funcionario = _context.Funcionarios.FirstOrDefault(F => F.CodFuncionario == CodFuncionario);
                    if(funcionario == null)
                    {
                        return NotFound("FUNCIONARIO INFORMADO NÃO EXISTE"); 
                    }
                    _context.Funcionarios.Remove(funcionario);
                    _context.SaveChanges();

                    return Ok("FUNCIONARIO DELETADO COM SUCESSO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
        }

        [HttpDelete("Filial")]
        public IActionResult DeletarFilial(int CodFilial)
        {
            using (var _context = new HotelEdisContext())
            {
                try
                {
                    Filial filial = _context.Filials.FirstOrDefault(F => F.CodFilial == CodFilial);
                    if(filial == null)
                    {
                        return NotFound("FILIAL INFORMADA NÃO EXISTE"); 
                    }
                    _context.Filials.Remove(filial);
                    _context.SaveChanges();

                    return Ok("FILIAL DELETADA COM SUCESSO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
        }

        [HttpDelete("Quarto")]
        public IActionResult DeletarQuarto(int CodFilial, string Numero)
        {
            using (var _context = new HotelEdisContext())
            {
                try
                {
                    Quarto quarto = _context.Quartos.FirstOrDefault(Q => Q.CodFilial== CodFilial && Q.Numero == Numero);
                    if(quarto == null)
                    {
                        return NotFound("QUARTO INFORMADO NÃO EXISTE"); 
                    }
                    _context.Quartos.Remove(quarto);
                    _context.SaveChanges();

                    return Ok("QUARTO DELETADO COM SUCESSO");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
        }
    
         // -------- UPDATES ---------- //
        [HttpPut("Cliente")]
        public IActionResult UpdateCliente(int CodCliente, string Nome, string Nacionalidade, string EMail, string? Endereco, string? Telefone)
        {
            using (var _context = new HotelEdisContext())
            {
                Cliente cliente = _context.Clientes.FirstOrDefault(C => C.CodCliente == CodCliente);
                if(cliente == null)
                {
                    return NotFound("CLIENTE INFORMADO NÃO EXISTE NA BASE DE DADOS"); 
                }

                cliente.Nome = Nome;
                cliente.Nacionalidade = Nacionalidade;
                cliente.EMail = EMail;
                cliente.Endereco = Endereco;
                cliente.Telefone = Telefone;

                _context.Entry(cliente).CurrentValues.SetValues(cliente);
                _context.SaveChanges();

                return Ok("CLIENTE ATUALIZADO COM SUCESSO");
            }
        }       

        [HttpPut("Funcionario")]
        public IActionResult UpdateFuncionario(int CodFuncionario, string Nome, string Funcao)
        {
            using (var _context = new HotelEdisContext())
            {
                Funcionario funcionario = _context.Funcionarios.FirstOrDefault(F => F.CodFuncionario == CodFuncionario);
                if(funcionario == null)
                {
                    return NotFound("FUNCIONARIO INFORMADO NÃO EXISTE NA BASE DE DADOS"); 
                }

                funcionario.Nome = Nome;
                funcionario.Funcao = Funcao;

                _context.Entry(funcionario).CurrentValues.SetValues(funcionario);
                _context.SaveChanges();

                return Ok("FUNCIONARIO ATUALIZADO COM SUCESSO");
            }
        }
    
        [HttpPut("Filial")]
        public IActionResult UpdateFilial(int CodFilial, string Nome, string Endereco, int NQuartos, double Estrelas)
        {
            using (var _context = new HotelEdisContext())
            {
                Filial filial = _context.Filials.FirstOrDefault(F => F.CodFilial == CodFilial);
                if(filial == null)
                {
                    return NotFound("FILIAL INFORMADA NÃO EXISTE NA BASE DE DADOS"); 
                }

                filial.Nome = Nome;
                filial.Endereco = Endereco;
                filial.NQuartos = NQuartos;
                filial.Estrelas = Estrelas;

                _context.Entry(filial).CurrentValues.SetValues(filial);
                _context.SaveChanges();

                return Ok("FILIAL ATUALIZADA COM SUCESSO");
            }
        }
    
        [HttpPut("Quarto")]
        public IActionResult UpdateQuarto(string Numero, int CodFilial,string Tipo, string Status, int PessoasMax, double? ServOpc1, double? ServOpc2, double? ServOpc3)
        {
            using (var _context = new HotelEdisContext())
            {
                Quarto quarto = _context.Quartos.FirstOrDefault(Q => Q.Numero == Numero && Q.CodFilial == CodFilial);
                if(quarto == null)
                {
                    return NotFound("QUARTO INFORMADO NÃO EXISTE NA BASE DE DADOS"); 
                }

                quarto.Numero = Numero;
                quarto.Tipo = Tipo;
                quarto.Status = Status;
                quarto.PessoasMax = PessoasMax;
                quarto.ServOpc1 = ServOpc1;
                quarto.ServOpc2 = ServOpc2;
                quarto.ServOpc3 = ServOpc3;

                _context.Entry(quarto).CurrentValues.SetValues(quarto);
                _context.SaveChanges();

                return Ok("QUARTO ATUALIZADO COM SUCESSO");
            }
        }
    
        [HttpPut("Reserva")]
        public IActionResult UpdateReserva(int CodReserva, DateOnly DataIn, DateOnly DataOut, string Numero, string CapOpcional)
        {
            using (var _context = new HotelEdisContext())
            {
                Reserva reserva = _context.Reservas.FirstOrDefault(R => R.CodReserva == CodReserva);
                Quarto quarto = _context.Quartos.FirstOrDefault(Q => Q.Numero == Numero);

                if(reserva == null)
                {
                    return NotFound("RESERVA INFORMADA NÃO EXISTE NA BASE DE DADOS"); 
                }

                if(quarto == null){
                        return BadRequest("QUARTO INFORMADO NÃO EXISTE");
                    }

                if(DataIn > DataOut){
                    return BadRequest("DATAS DE RESERVA INVALIDAS: Data de Check-Out não pode ser anterior a Check-In");
                }

                if(quarto.Status != "Disponível"){
                        return BadRequest("QUARTO INDISPONÍVEL.");
                }

                reserva.DataIn  = DataIn;
                reserva.DataOut = DataOut;
                reserva.Numero =  Numero;
                reserva.CapOpcional =CapOpcional;

                _context.Entry(reserva).CurrentValues.SetValues(reserva);
                _context.SaveChanges();

                return Ok("RESERVA ATUALIZADO COM SUCESSO");
            }
        }
    
        [HttpPut("Estadia")]
        public IActionResult UpdateEstadia(int CodEstadia, string FormaPagamento)
        {
            using (var _context = new HotelEdisContext())
            {
                Estadia estadia = _context.Estadia.FirstOrDefault(E => E.CodEstadia == CodEstadia);
                if(estadia == null)
                {
                    return NotFound("ESTADIA INFORMADA NÃO EXISTE NA BASE DE DADOS"); 
                }

                estadia.FormaPagamento = FormaPagamento;

                _context.Entry(estadia).CurrentValues.SetValues(estadia);
                _context.SaveChanges();

                return Ok("ESTADIA ATUALIZADO COM SUCESSO");
            }
        }
    }
}
