﻿using System;
using System.Collections.Generic;

namespace Hotel_Edis;

public partial class Filial
{
    public int CodFilial { get; set; }

    public string Nome { get; set; } = null!;

    public string Endereco { get; set; } = null!;

    public int NQuartos { get; set; }

    public double? Estrelas { get; set; }

    public virtual ICollection<Quarto> Quartos { get; set; } = new List<Quarto>();

    public Filial(string Nome, string Endereco, int NQuartos)
    {
        this.CodFilial = CodFilial;
        this.Nome = Nome;
        this.Endereco = Endereco;
        this.NQuartos = NQuartos;
    }
}
