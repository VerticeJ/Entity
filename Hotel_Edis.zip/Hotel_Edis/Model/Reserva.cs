﻿using System;
using System.Collections.Generic;

namespace Hotel_Edis;

public partial class Reserva
{
    public int CodReserva { get; set; }

    public DateOnly DataIn { get; set; }

    public DateOnly DataOut { get; set; }

    public string Numero { get; set; } = null!;

    public int CodFuncionario { get; set; }

    public int CodCliente { get; set; }

    public string? CapOpcional { get; set; }

    public virtual Cliente CodClienteNavigation { get; set; } = null!;

    public virtual Funcionario CodFuncionarioNavigation { get; set; } = null!;

    public virtual ICollection<Estadia> Estadia { get; set; } = new List<Estadia>();

    public virtual Quarto NumeroNavigation { get; set; } = null!;

    public Reserva(DateOnly DataIn, DateOnly DataOut, string Numero, int CodFuncionario, int CodCliente, string CapOpcional){
        this.DataIn = DataIn;
        this.DataOut = DataOut;
        this.Numero = Numero;
        this.CodFuncionario = CodFuncionario;
        this.CodCliente = CodCliente;
        this.CapOpcional = CapOpcional;
    }
}
