﻿using System;
using System.Collections.Generic;

namespace Hotel_Edis;

public partial class Funcionario
{
    public int CodFuncionario { get; set; }

    public string Nome { get; set; } = null!;

    public string Funcao { get; set; } = null!;

    public virtual ICollection<Reserva> Reservas { get; set; } = new List<Reserva>();

    public Funcionario (string Nome, string Funcao){
        this.Nome = Nome;
        this.Funcao = Funcao;
    }
}
