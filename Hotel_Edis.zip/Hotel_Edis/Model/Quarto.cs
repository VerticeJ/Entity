﻿using System;
using System.Collections.Generic;

namespace Hotel_Edis;

public partial class Quarto
{
    public string Numero { get; set; } = null!;

    public string Tipo { get; set; } = null!;

    public string Status { get; set; } = null!;

    public int PessoasMax { get; set; }

    public double? ServOpc1 { get; set; }

    public double? ServOpc2 { get; set; }

    public double? ServOpc3 { get; set; }

    public int CodFilial { get; set; }

    public virtual Filial CodFilialNavigation { get; set; } = null!;

    public virtual ICollection<Reserva> Reservas { get; set; } = new List<Reserva>();

    public Quarto(string Numero, int CodFilial,string Tipo, string Status, int PessoasMax){
        this.Numero = Numero;
        this.CodFilial = CodFilial;
        this.Tipo = Tipo;
        this.Status = Status;
        this.PessoasMax = PessoasMax;
    } 
}
