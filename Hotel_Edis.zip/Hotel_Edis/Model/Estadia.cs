﻿using System;
using System.Collections.Generic;

namespace Hotel_Edis;

public partial class Estadia
{
    public int CodEstadia { get; set; }

    public double Valor { get; set; }

    public string FormaPagamento { get; set; } = null!;

    public int CodReserva { get; set; }

    public virtual Reserva CodReservaNavigation { get; set; } = null!;

    public virtual ICollection<Consumo> Consumos { get; set; } = new List<Consumo>();

    public Estadia(double Valor, string FormaPagamento,  int CodReserva){
        this.Valor = Valor;
        this.FormaPagamento = FormaPagamento;
        this.CodReserva = CodReserva;
    }

}
