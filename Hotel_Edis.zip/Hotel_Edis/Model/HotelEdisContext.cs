﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Hotel_Edis;

public partial class HotelEdisContext : DbContext
{
    public HotelEdisContext()
    {
    }

    public HotelEdisContext(DbContextOptions<HotelEdisContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Cliente> Clientes { get; set; }

    public virtual DbSet<Consumo> Consumos { get; set; }

    public virtual DbSet<Estadia> Estadia { get; set; }

    public virtual DbSet<Filial> Filials { get; set; }

    public virtual DbSet<Funcionario> Funcionarios { get; set; }

    public virtual DbSet<Quarto> Quartos { get; set; }

    public virtual DbSet<Reserva> Reservas { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=.\\;Database=Hotel_Edis;Trusted_Connection=True;MultipleActiveResultSets=true;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Cliente>(entity =>
        {
            entity.HasKey(e => e.CodCliente).HasName("PK__Cliente__DF8324D7B575DC30");

            entity.ToTable("Cliente");

            entity.Property(e => e.EMail)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("E_mail");
            entity.Property(e => e.Endereco)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Nacionalidade)
                .HasMaxLength(25)
                .IsUnicode(false);
            entity.Property(e => e.Nome)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Telefone)
                .HasMaxLength(15)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Consumo>(entity =>
        {
            entity.HasKey(e => e.CodConsumo).HasName("PK__Consumo__2638892E8173F626");

            entity.ToTable("Consumo");

            entity.Property(e => e.EntregueQuarto)
                .HasMaxLength(3)
                .IsUnicode(false)
                .HasColumnName("Entregue_Quarto");

            entity.HasOne(d => d.CodEstadiaNavigation).WithMany(p => p.Consumos)
                .HasForeignKey(d => d.CodEstadia)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_CodEstadia");
        });

        modelBuilder.Entity<Estadia>(entity =>
        {
            entity.HasKey(e => e.CodEstadia).HasName("PK__Estadia__A423EC7FF137DD63");

            entity.Property(e => e.FormaPagamento)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("Forma_Pagamento");

            entity.HasOne(d => d.CodReservaNavigation).WithMany(p => p.Estadia)
                .HasForeignKey(d => d.CodReserva)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_CodReserva");
        });

        modelBuilder.Entity<Filial>(entity =>
        {
            entity.HasKey(e => e.CodFilial).HasName("PK__Filial__6EFE55266C041639");

            entity.ToTable("Filial");

            entity.Property(e => e.Endereco)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.NQuartos).HasColumnName("N_Quartos");
            entity.Property(e => e.Nome)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Funcionario>(entity =>
        {
            entity.HasKey(e => e.CodFuncionario).HasName("PK__Funciona__E470B74549CA9048");

            entity.ToTable("Funcionario");

            entity.Property(e => e.Funcao)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Nome)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Quarto>(entity =>
        {
            entity.HasKey(e => e.Numero).HasName("PK__Quarto__7E532BC7B7519536");

            entity.ToTable("Quarto");

            entity.Property(e => e.Numero)
                .HasMaxLength(15)
                .IsUnicode(false);
            entity.Property(e => e.PessoasMax).HasColumnName("Pessoas_Max");
            entity.Property(e => e.ServOpc1).HasColumnName("Serv_Opc_1");
            entity.Property(e => e.ServOpc2).HasColumnName("Serv_Opc_2");
            entity.Property(e => e.ServOpc3).HasColumnName("Serv_Opc_3");
            entity.Property(e => e.Status)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.Tipo)
                .HasMaxLength(15)
                .IsUnicode(false);

            entity.HasOne(d => d.CodFilialNavigation).WithMany(p => p.Quartos)
                .HasForeignKey(d => d.CodFilial)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_CodFilial");
        });

        modelBuilder.Entity<Reserva>(entity =>
        {
            entity.HasKey(e => e.CodReserva).HasName("PK__Reserva__A7508B911CEF01C4");

            entity.ToTable("Reserva");

            entity.Property(e => e.CapOpcional)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("Cap_Opcional");
            entity.Property(e => e.DataIn).HasColumnName("Data_In");
            entity.Property(e => e.DataOut).HasColumnName("Data_Out");
            entity.Property(e => e.Numero)
                .HasMaxLength(15)
                .IsUnicode(false);

            entity.HasOne(d => d.CodClienteNavigation).WithMany(p => p.Reservas)
                .HasForeignKey(d => d.CodCliente)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_Cliente_CodCliente");

            entity.HasOne(d => d.CodFuncionarioNavigation).WithMany(p => p.Reservas)
                .HasForeignKey(d => d.CodFuncionario)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_Funcionario_CodFuncionario");

            entity.HasOne(d => d.NumeroNavigation).WithMany(p => p.Reservas)
                .HasForeignKey(d => d.Numero)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_Quarto_Numero");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
