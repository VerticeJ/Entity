﻿using System;
using System.Collections.Generic;

namespace Hotel_Edis;

public partial class Cliente
{
    public int CodCliente { get; set; }

    public string Nome { get; set; } = null!;

    public string Nacionalidade { get; set; } = null!;

    public string? Endereco { get; set; }

    public string EMail { get; set; } = null!;

    public string? Telefone { get; set; }

    public virtual ICollection<Reserva> Reservas { get; set; } = new List<Reserva>();

    public Cliente (string Nome, string Nacionalidade, string EMail){
        this.Nome = Nome;
        this.Nacionalidade = Nacionalidade;
        this.EMail = EMail;
    }
}
