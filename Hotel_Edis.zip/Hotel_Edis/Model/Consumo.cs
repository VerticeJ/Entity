﻿using System;
using System.Collections.Generic;

namespace Hotel_Edis;

public partial class Consumo
{
    public int CodConsumo { get; set; }

    public double Valor { get; set; }

    public string EntregueQuarto { get; set; } = null!;

    public int CodEstadia { get; set; }

    public virtual Estadia CodEstadiaNavigation { get; set; } = null!;

    public Consumo(double Valor , string EntregueQuarto, int CodEstadia)
    {
        this.Valor = Valor;
        this.EntregueQuarto = EntregueQuarto;
        this.CodEstadia = CodEstadia;
    }
}
